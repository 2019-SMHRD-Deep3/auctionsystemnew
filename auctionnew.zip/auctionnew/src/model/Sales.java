package model;

public class Sales {
	private int salesold;

	
	
	
	public Sales() {
	}

	public Sales(int salesold) {
		super();
		this.salesold = salesold;
	}

	public int getSalesold() {
		return salesold;
	}

	public void setSalesold(int salesold) {
		this.salesold = salesold;
	}
	
}
