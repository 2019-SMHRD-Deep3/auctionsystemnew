package model;

public class Reservation {
	private int resnum;
	private int proid;
	private String asdepdate;
	private String asaridate;
	private String prodate;
	private String dep;
	public int getResnum() {
		return resnum;
	}
	public void setResnum(int resnum) {
		this.resnum = resnum;
	}
	public int getProid() {
		return proid;
	}
	public void setProid(int proid) {
		this.proid = proid;
	}
	public String getAsdepdate() {
		return asdepdate;
	}
	public void setAsdepdate(String asdepdate) {
		this.asdepdate = asdepdate;
	}
	public String getAsaridate() {
		return asaridate;
	}
	public void setAsaridate(String asaridate) {
		this.asaridate = asaridate;
	}
	public String getProdate() {
		return prodate;
	}
	public void setProdate(String prodate) {
		this.prodate = prodate;
	}
	public String getDep() {
		return dep;
	}
	public void setDep(String dep) {
		this.dep = dep;
	}
	
}
