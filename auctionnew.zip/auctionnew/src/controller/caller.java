package controller;

import java.util.Scanner;

public class caller {

	public static void main(String[] args) {

		
		System.out.println("======��ȭ��ȣ��======");

}
}